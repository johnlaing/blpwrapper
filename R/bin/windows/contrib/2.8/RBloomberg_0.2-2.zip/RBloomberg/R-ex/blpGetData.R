### Name: blpGetData
### Title: Get Bloomberg Data
### Aliases: blpGetData blpGetData.default blpGetData.BlpCOMConnect
### Keywords: math

### ** Examples

## Not run: 
##D conn <- blpConnect()
##D 
##D ## Snapshot 
##D blpGetData(conn, c("ED5 Comdty","ED6 Comdty","ED7 Comdty",
##D "ED8 Comdty"), "BID")
##D 
##D ## Historical (last 30 days)
##D blpGetData(conn, "ED1 Comdty", "PX_LAST",
##D start=Sys.Date() - 30)
##D 
##D ## Intraday bars (last hour in 2 min bars)
##D blpGetData(conn, "ED1 Comdty", c("BID","ASK"),
##D start=Sys.time() - 3600, barfields="OPEN", barsize=2)
##D 
##D ## Tick-by-tick (3 minutes starting an hour ago)
##D blpGetData(conn, "ED1 Comdty", c("BID"),
##D start=Sys.time() - 3600,
##D end=Sys.time() - 3420, barsize=0)
##D 
##D # Example of 3D data. Note ugly dates.
##D blpGetData(conn, c("ED5 Comdty","ED6 Comdty","ED7 Comdty",
##D "ED8 Comdty"), c("BID","ASK"),
##D start=Sys.time() - 86400 * 5,
##D retval="matrix")
##D 
##D blpDisconnect(conn)
##D 
##D ## Please consult the unit tests in inst/runit-tests for more examples.
##D 
## End(Not run)



