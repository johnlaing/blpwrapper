library(RDCOMClient)

conn <- COMCreate("Bloomberg.Data.1")

results_var <- 0

return_val <- conn$Subscribe("RYA ID Equity", 1, c("PX_LAST"))

for (i in 1:100) {
  cat(i)
  cat(return_val)
}
