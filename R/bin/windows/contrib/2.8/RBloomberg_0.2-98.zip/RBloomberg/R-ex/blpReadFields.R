### Name: blpReadFields
### Title: Read bbfields.tbl file into workspace.
### Aliases: blpReadFields
### Keywords: math

### ** Examples

.bbfields <- blpReadFields()



