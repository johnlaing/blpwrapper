### Name: blh
### Title: Get Bloomberg Historical Data
### Aliases: blh
### Keywords: math

### ** Examples

# Please consult unit tests for more examples.
## Not run: 
##D library(RBloomberg)
##D conn <- blpConnect()
##D 
##D blh(conn, "GOLDS Comdty", "PX_LAST", "20090101", "20090107")
##D result <- blh(conn, "GOLDS Comdty", "PX_LAST", Sys.Date() - 10)
##D 
##D result
##D 
##D library(zoo)
##D zoo(result, order.by = rownames(result))
##D 
##D blpDisconnect(conn)
##D 
## End(Not run)



