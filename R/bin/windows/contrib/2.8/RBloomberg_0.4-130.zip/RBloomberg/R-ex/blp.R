### Name: blp
### Title: Get Bloomberg Reference Data
### Aliases: blp
### Keywords: math

### ** Examples

# Please consult unit tests for more examples.
## Not run: 
##D library(RBloomberg)
##D conn <- blpConnect()
##D 
##D bdp(conn, "AMZN US Equity", "NAME")
##D 
##D securities <- c("AMZN US Equity", "OCN US Equity")
##D fields <- c("NAME", "PX_LAST", "TIME", "SETTLE_DT")
##D bdp(conn, securities, fields)
##D 
##D securities <- c("AMZN US Equity", "OCN US Equity")
##D fields <- c("CUST_TRR_RETURN_HOLDING_PER")
##D override_fields <- c("CUST_TRR_START_DT", "CUST_TRR_END_DT", "CUST_TRR_CRNCY")
##D overrides <- c("20090601", "20091231", "PRC")
##D bdp(conn, securities, fields, override_fields, overrides)
##D 
##D securities <- c("RYA ID EQUITY", "OCN US EQUITY", "YHOO US EQUITY")
##D fields <- c("LT_DEBT_TO_COM_EQY")
##D override_fields <- c("EQY_FUND_DT")
##D overrides <- c("20051231")
##D bdp(conn, securities, fields, override_fields, overrides)
##D 
##D override_fields <- c("EQY_FUND_DT")
##D overrides <- c("20061231")
##D bdp(conn, securities, fields, override_fields, overrides)
##D 
## End(Not run)



