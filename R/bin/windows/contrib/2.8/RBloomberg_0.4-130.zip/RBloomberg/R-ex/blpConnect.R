### Name: blpConnect
### Title: Open or shut a connection to Bloomberg
### Aliases: blpConnect blpDisconnect
### Keywords: math

### ** Examples

## Not run: 
##D conn <- blpConnect()
##D blpDisconnect(conn)
## End(Not run)



