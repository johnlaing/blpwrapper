### Name: blh
### Title: Get Bloomberg Historical Data
### Aliases: blh
### Keywords: math

### ** Examples

# Please consult unit tests for more examples.
## Not run: 
##D library(RBloomberg)
##D conn <- blpConnect()
##D 
##D bdh(conn, "GOLDS Comdty", "PX_LAST", "20090101", "20090107")
##D 
##D start.date <- as.POSIXct("2009-01-01")
##D end.date <- as.POSIXct("2009-01-07")
##D bdh(conn, "GOLDS Comdty", "PX_LAST", start.date, end.date)
##D 
##D bdh(conn, "GOLDS Comdty", "PX_LAST", Sys.Date() - 10)
##D 
##D library(zoo)
##D result <- bdh(conn, "GOLDS Comdty", "PX_LAST", Sys.Date() - 10)
##D zoo(result, order.by = rownames(result))
##D 
##D bdh(conn, "GOLDS Comdty", "PX_LAST", Sys.Date() - 366, 
##D     option_names = "periodicitySelection", option_values = "MONTHLY")
##D 
##D blpDisconnect(conn)
##D 
## End(Not run)



