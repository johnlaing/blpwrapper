### Name: blh
### Title: Get Bloomberg Historical Data
### Aliases: blh
### Keywords: math

### ** Examples

# Please consult unit tests for more examples.
## Not run: 
##D library(RBloomberg)
##D conn <- blpConnect()
##D 
##D bdh(conn, "GOLDS Comdty", "PX_LAST", "20090101", "20090107")
##D 
##D Sys.setenv(TZ="GMT")
##D start.date <- as.POSIXct("2009-01-01")
##D end.date <- as.POSIXct("2009-01-07")
##D 
##D bdh(conn, "GOLDS Comdty", "PX_LAST", start.date, end.date)
##D 
##D bdh(conn, "GOLDS Comdty", "PX_LAST", Sys.Date() - 10)
##D 
##D library(zoo)
##D result <- bdh(conn, "GOLDS Comdty", "PX_LAST", Sys.Date() - 10)
##D zoo(result, order.by = rownames(result))
##D 
##D bdh(conn, "GOLDS Comdty", "PX_LAST", Sys.Date() - 366, 
##D     option_names = "periodicitySelection", option_values = "MONTHLY")
##D 
##D df <- bdh(conn, c("AMZN US Equity", "GOOG US Equity", "MSFT US Equity"), 
##D     c("PX_LAST", "BID"), start.date, end.date)
##D df
##D na.omit(df)
##D 
##D bdh(conn, c("AMZN US Equity"), c("PX_LAST", "BID"), start.date, end.date, 
##D     always.display.tickers = TRUE)
##D 
##D bdh(conn, c("AMZN US Equity"), c("PX_LAST", "BID"), start.date, end.date, 
##D     always.display.tickers = TRUE, dates.as.row.names = FALSE)
##D 
##D bdh(conn, "/SEDOL1/2292612 EQUITY", c("PX_LAST", "BID"), "20090401", "20090410")
##D 
##D # We should get NULL back when there's no data...
##D bdh(conn, "/SEDOL1/2292612 EQUITY", c("PX_LAST", "BID"), "20090405", "20090405")
##D 
##D # To return rows for all requested dates, even when they have no data...
##D bdh(conn, "/SEDOL1/2292612 EQUITY", c("PX_LAST", "BID"), "20090405", "20090405", 
##D     include.non.trading.days = TRUE)
##D 
##D # This is equivalent to...
##D bdh(conn, "/SEDOL1/2292612 EQUITY", c("PX_LAST", "BID"), "20090405", "20090405",
##D     option_names = c("nonTradingDayFillOption", "nonTradingDayFillMethod"),
##D     option_values = c("ALL_CALENDAR_DAYS", "NIL_VALUE"))
##D 
##D # Consult API documentation for other available option values.
##D bdh(conn, "/SEDOL1/2292612 EQUITY", c("PX_LAST", "BID"), "20090405", "20090405",
##D     option_names = c("nonTradingDayFillOption", "nonTradingDayFillMethod"),
##D     option_values = c("ALL_CALENDAR_DAYS", "PREVIOUS_VALUE"))
##D 
##D blpDisconnect(conn)
##D 
## End(Not run)



