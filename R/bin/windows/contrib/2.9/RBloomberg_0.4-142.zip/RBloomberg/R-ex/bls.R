### Name: bls
### Title: Get Bloomberg Bulk Data
### Aliases: bls
### Keywords: math

### ** Examples

# Please consult unit tests for more examples.
## Not run: 
##D library(RBloomberg)
##D conn <- blpConnect(log.level = "finest")
##D 
##D security <- c("BKIR ID Equity")
##D field <- c("DVD_HIST")
##D 
##D bds(conn, security, field)[1:5,]
##D 
##D security <- "TYA Comdty"
##D field <- "FUT_DELIVERABLE_BONDS"
##D 
##D bds(conn, security, field)[1:5,]
##D 
##D security <- "UKX Index"
##D field <- "INDX_MEMBERS"
##D 
##D bds(conn, security, field)[1:5,]
##D 
##D securities <- c("UKX Index", "SPX Index")
##D fields <- c("INDX_MEMBERS", "INDX_MEMBERS2", "INDX_MEMBERS3")
##D 
##D bds(conn, securities, fields)[c(1:5, 350:355),]
##D 
##D 
## End(Not run)



