blpDisconnect <- function(conn){
  gc(verbose=FALSE);
}
